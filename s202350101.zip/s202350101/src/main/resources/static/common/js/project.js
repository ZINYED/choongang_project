/**
 * 
 */

 function goto(url) {

	 location.href = url;
	 
 }