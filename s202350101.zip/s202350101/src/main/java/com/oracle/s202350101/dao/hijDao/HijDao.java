package com.oracle.s202350101.dao.hijDao;

public interface HijDao {

}
