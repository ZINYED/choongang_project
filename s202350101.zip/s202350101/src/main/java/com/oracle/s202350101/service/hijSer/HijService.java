package com.oracle.s202350101.service.hijSer;

public interface HijService {

}
