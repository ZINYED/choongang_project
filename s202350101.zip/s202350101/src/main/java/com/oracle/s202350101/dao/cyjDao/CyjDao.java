package com.oracle.s202350101.dao.cyjDao;

public interface CyjDao {

}
