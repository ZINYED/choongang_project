package com.oracle.s202350101.dao.ljhDao;

import com.oracle.s202350101.model.PrjInfo;

public interface LjhDao {

	PrjInfo 		getProject(int project_id);

}
