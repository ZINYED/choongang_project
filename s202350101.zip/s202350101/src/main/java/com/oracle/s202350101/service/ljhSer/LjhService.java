package com.oracle.s202350101.service.ljhSer;

import com.oracle.s202350101.model.PrjInfo;

public interface LjhService {

	PrjInfo 		getProject(int project_id);

}
