package com.oracle.s202350101.dao.jmhDao;

public class JmhDaoImpl implements JmhDao {

}
