package com.oracle.s202350101.dao.lkhDao;

public interface LkhDao {

}
