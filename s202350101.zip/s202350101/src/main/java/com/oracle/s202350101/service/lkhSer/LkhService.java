package com.oracle.s202350101.service.lkhSer;

public interface LkhService {

}
