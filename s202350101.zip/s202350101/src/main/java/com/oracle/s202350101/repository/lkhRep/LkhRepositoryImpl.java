package com.oracle.s202350101.repository.lkhRep;

public class LkhRepositoryImpl {

}
