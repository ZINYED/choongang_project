package com.oracle.s202350101.dao.lkhDao;

public class LkhDaoImpl implements LkhDao {

}
