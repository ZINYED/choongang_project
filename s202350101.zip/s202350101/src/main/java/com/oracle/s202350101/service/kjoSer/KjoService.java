package com.oracle.s202350101.service.kjoSer;

public interface KjoService {

}
