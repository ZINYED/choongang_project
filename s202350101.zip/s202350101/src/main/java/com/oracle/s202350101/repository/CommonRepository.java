package com.oracle.s202350101.repository;

public class CommonRepository {

}
