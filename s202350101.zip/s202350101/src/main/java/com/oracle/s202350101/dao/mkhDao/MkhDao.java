package com.oracle.s202350101.dao.mkhDao;

public interface MkhDao {

}
