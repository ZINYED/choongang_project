package com.oracle.s202350101.repository.kjoRep;

public interface KjoRepository {

}
